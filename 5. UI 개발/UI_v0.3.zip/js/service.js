
window.onload = function () {
    new WOW().init();
    getChart();
    selectValue();
    myChart.update();
};

var region1;
var region2;
var region1ValueLabel = [];
var region2ValueLabel = [];
var region1Value;
var region2Value;

//JSON 형식의 파일로 데이터를 받아올 것
var seoulData = [15, 20, 15, 30, 25, 15, 20, 15, 30, 25, 15, 20, 15, 30, 25];
var jeonNamData = [15, 20, 15, 30, 25, 15, 20, 15, 30, 25, 15, 20, 15, 30, 25];


/* 지역 셀렉트 박스 관련 함수*/
function selectValue() {
    region1 = document.getElementById("selectedRegion1")
    region2 = document.getElementById("selectedRegion2")
    region1ValueLabel = [];
    region2ValueLabel = [];

    region1Value = region1.options[region1.selectedIndex].value;
    region2Value = region2.options[region2.selectedIndex].value;

    region1ValueLabel.push(String(region1Value));
    chartData.datasets[0].label = region1ValueLabel;
    region2ValueLabel.push(String(region2Value));
    chartData.datasets[1].label = region2ValueLabel;
    myChart.update();
    if (myChart) {
        myChart.destroy();
    }
    getChart();
}



function getChart() {
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");

    var selectYearValue1 = selectYear1.options[selectYear1.selectedIndex].value;
    var selectYearValue2 = selectYear2.options[selectYear2.selectedIndex].value;

    var selectedYears = [];
    for (var i = parseInt(selectYearValue1); i <= parseInt(selectYearValue2); i++) {
        selectedYears.push(String(i));
    }
    if (myChart) {
        myChart.destroy();
    }
    chartData.labels = selectedYears;
    drawChart("serviceChart", "bar", chartData)
    myChart.update();
}



var chartData = {
    labels: [2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
    datasets: [
        {
            label: "서울특별시",
            data: seoulData, // 실제 데이터로 대체
            backgroundColor: "#1c3664",
            // borderColor: "rgba(75, 192, 192, 1)",
            borderWidth: 1,
        },
        {
            label: "전라남도",
            data: jeonNamData, // 실제 데이터로 대체
            backgroundColor: "red",
            // borderColor: "rgba(75, 192, 192, 1)",
            borderWidth: 1,
        }]
};

var myChart

function drawChart(chartId, chartType, data) {
    var ctx = document.getElementById(chartId).getContext('2d');
    myChart = new Chart(ctx, {
        type: chartType,
        data: data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '각 지역 기데수명 데이터',

                    padding: {
                        top: 10,
                    }

                }
            }
            ,
            scales: {
                y: {
                    beginAtZero: false
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        },
    });
}



function addYearEndOption() {
    removeYearEndOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2026; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearEndOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}