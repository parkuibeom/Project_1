//서블릿에서 데이터를 JSON 형태로 받아옴
//서버는 아직 미구현이기에 임시로 JSON 형식 데이터 할당
//데이터는 지역 -> 연도 -> 4대 질병(고지혈증, 치매, 당뇨, 고혈압) 순으로 저장
var newChart;
var jeonnamRegion;
var labelData = []; //라벨 데이터

var selectYearStart = document.getElementById("year-select-start");
var selectYearEed = document.getElementById("year-select-end");
var selectYearStartValue
var selectYearEndValue



var jeonnamSelect = document.getElementById('jeonnam-select');
var jeonnamSelectValue


//해남 고지혈증, 치매, 당뇨병, 고혈압 임시 변수
var haenamInputHyper;
var haenamInputDementia;
var haenamInputDiabetes;
var haenamInputHbp;

//고지혈증, 치매, 당뇨, 고혈압 순 데이터
var haenamHyperlipidemia = [];
var haenamDementia = [];
var haenamDiabetes = [];
var haenamHbp = [];

//각 질병 버튼 상태
var hyperBtnStatus = "off";
var demenBtnStatus = "off";
var diaBtnStatus = "off";
var hbpBtnStatus = "off";


var haenamData = { //해남 데이터
    2013: {
        'hyperlipidemia': 35,   // 고지혈증
        'dementia': 12,        // 치매
        'diabetes': 28,        // 당뇨
        'hbp': 40              // 고혈압
    },
    2014: {
        'hyperlipidemia': 37,
        'dementia': 14,
        'diabetes': 30,
        'hbp': 42
    },
    2015: {
        'hyperlipidemia': 33,
        'dementia': 11,
        'diabetes': 25,
        'hbp': 38
    },
    2016: {
        'hyperlipidemia': 36,
        'dementia': 15,
        'diabetes': 29,
        'hbp': 41
    },
    2017: {
        'hyperlipidemia': 34,
        'dementia': 16,
        'diabetes': 27,
        'hbp': 39
    },
    2018: {
        'hyperlipidemia': 38,
        'dementia': 18,
        'diabetes': 31,
        'hbp': 45
    },
    2019: {
        'hyperlipidemia': 32,
        'dementia': 19,
        'diabetes': 24,
        'hbp': 37
    },
    2020: {
        'hyperlipidemia': 39,
        'dementia': 17,
        'diabetes': 32,
        'hbp': 46
    },
    2021: {
        'hyperlipidemia': 31,
        'dementia': 9,
        'diabetes': 23,
        'hbp': 36
    },
    2022: {
        'hyperlipidemia': 40,
        'dementia': 19,
        'diabetes': 33,
        'hbp': 80 //해남 구분용 데이터 원래는 48
    },
    2023: {
        'hyperlipidemia': 40,
        'dementia': 19,
        'diabetes': 33,
        'hbp': 80 //해남 구분용 데이터 원래는 48
    }
};

function initData() {
    labelData = []; //라벨 데이터 초기화
    //데이터 초기화

    haenamHyperlipidemia = [];
    haenamDementia = [];
    haenamDiabetes = [];
    haenamHbp = [];

    selectYearStartValue = selectYearStart.options[selectYearStart.selectedIndex].value;
    selectYearEndValue = selectYearEed.options[selectYearEed.selectedIndex].value;

    jeonnamSelectValue = jeonnamSelect.options[jeonnamSelect.selectedIndex].value;





    for (let i = selectYearStartValue; i <= selectYearEndValue; i++) {
        labelData.push(i);
        haenamHyperlipidemia.push(haenamData[i]["hyperlipidemia"]);
        haenamDementia.push(haenamData[i]["dementia"]);
        haenamDiabetes.push(haenamData[i]["diabetes"]);
        haenamHbp.push(haenamData[i]["hbp"]);
    }
}

//질병 데이터 체크 함수
function checkBtn() {
    //고지혈증 버튼
    if (hyperBtnStatus === "on") {

        haenamInputHyper = haenamHyperlipidemia;
    }

    else if (hyperBtnStatus === "off") {

        haenamInputHyper = [];
    }

    //치매 버튼
    if (demenBtnStatus === "on") {

        haenamInputDementia = haenamDementia;
    }

    else if (demenBtnStatus === "off") {

        haenamInputDementia = [];
    }

    //당뇨병 버튼
    if (diaBtnStatus === "on") {

        haenamInputDiabetes = haenamDiabetes;
    }

    else if (diaBtnStatus === "off") {

        haenamInputDiabetes = [];
    }

    //고혈압 버튼
    if (hbpBtnStatus === "on") {

        haenamInputHbp = haenamHbp;
    }

    else if (hbpBtnStatus === "off") {

        haenamInputHbp = [];
    }
}

function regionCheck() {
    initData();
    checkBtn()
    //지역 체크 함수
    newChart.destroy();
    // for (let i = 0; i < labelData.length; i++) {
    //     if (typeof labelData[i] === 'string') {
    //         labelData[i] = parseInt(labelData[i]);
    //     }
    // }
    if (hyperBtnStatus === "on") {
        newChart.destroy;
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '전라남도 고지혈증',
                        data: haenamInputHyper,
                        borderWidth: 1,
                        backgroundColor: ['red'],
                        borderColor: ['red']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고지혈증 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (demenBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '전라남도 치매',
                        data: haenamInputDementia,
                        borderWidth: 1,
                        backgroundColor: ['yellow'],
                        borderColor: ['yellow']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '치매 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (diaBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '전라남도 당뇨',
                        data: haenamInputDiabetes,
                        borderWidth: 1,
                        backgroundColor: ['black'],
                        borderColor: ['black']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '당뇨 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (hbpBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '전라남도 고혈압',
                        data: haenamInputHbp,
                        borderWidth: 1,
                        backgroundColor: ['lightblue'],
                        borderColor: ['lightblue']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고혈압 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
}

//창 로딩시 
window.onload = function () {
    new WOW().init();
}






//차트 DOM으로 받아오기
var ctx = document.getElementById('myChart');

labelData = Object.keys(haenamData);


//차트 데이터
let chartData = {
    type: 'bar',
    data: {
        labels: labelData, //x라벨
        datasets: [{ //chart에 넣을 데이터
            label: '고지혈증',
            borderWidth: 1,
            backgroundColor: ['red'],
            borderColor: ['red']
        },
        {
            label: '치매',
            borderWidth: 1,
            backgroundColor: ['yellow'],
            borderColor: ['yellow']
        },
        {
            label: '당뇨    ',
            borderWidth: 1,
            backgroundColor: ['black'],
            borderColor: ['black']
        },
        {
            label: '고혈압',
            borderWidth: 1,
            backgroundColor: ['lightblue'],
            borderColor: ['lightblue']
        }]
    },
    options: {
        plugins: {
            title: {
                display: true,
                text: '지역 데이터(단위 : %)',
                font: {
                    size: 20,
                },
                padding: {
                    top: 10,
                    bottom: 30
                }
            }
        }
        ,
        scales: {
            y: {
                beginAtZero: true
            }
        }
        , responsive: true, //차트 반응형 옵션
        maintainAspectRatio: true,
    }
}

//차트 틀 생성
newChart = new Chart(ctx, chartData);





//셀렉트 박스 차트 적용(xlabel 범위)
// document.getElementById('year-select-start').addEventListener('change', function () {
//     selectStart = document.getElementById('year-select-start').value;
//     if (region === undefined) {
//         selectEnd = document.getElementById('year-select-end').value;
//         alert("지역을 선택해주세요");
//     }
//     initData();

//     checkBtn();
//     regionCheck();

// });

// document.getElementById('year-select-end').addEventListener('change', function () {
//     selectStart = document.getElementById('year-select-start').value;
//     if (region === undefined) {
//         selectEnd = document.getElementById('year-select-end').value;
//         alert("지역을 선택해주세요");
//     }
//     initData();

//     checkBtn();
//     regionCheck();

// });





//해남 셀렉트 차트 적용(데이터)
document.getElementById('jeonnam-select').addEventListener('change', function () {
    jeonnamSelect = document.getElementById('jeonnam-select');
    jeonnamSelectValue = jeonnamSelect.options[jeonnamSelect.selectedIndex].value;
    // if (jeonnamSelectValue !== "0") {
    //     jeonnamRegion = parseInt(jeonnamSelectValue);
    // }
    jeonnamSelectValue;
    newChart.destroy();
    checkBtn();
    regionCheck();
});

//고지혈증 버튼
document.getElementById('hyper').addEventListener('click', function () {
    if (hyperBtnStatus === "on") {
        hyperBtnStatus = "off"
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (hyperBtnStatus === "off") {
        hyperBtnStatus = "on";
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;

    }
    else {
        alert("지역을 선택해주세요");
    }
    checkBtn();
    regionCheck();

})

//치매 버튼
document.getElementById('dementia').addEventListener('click', function () {
    if (demenBtnStatus === "on") {
        demenBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (demenBtnStatus === "off") {
        demenBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    checkBtn();
    regionCheck();

})

//당뇨 버튼
document.getElementById('diabetes').addEventListener('click', function () {
    if (diaBtnStatus === "on") {
        diaBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (diaBtnStatus === "off") {
        diaBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    checkBtn();
    regionCheck();
})

//고혈압 버튼
document.getElementById('hbp').addEventListener('click', function () {
    if (hbpBtnStatus === "on") {
        hbpBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
    }
    else if (hbpBtnStatus === "off") {
        hbpBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }

    checkBtn();
    regionCheck();

})



function addYearOption() {
    removeYearOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2023; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}