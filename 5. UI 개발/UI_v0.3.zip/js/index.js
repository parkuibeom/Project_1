window.onload = function () {
    new WOW().init();
    var posts = [
        { id: 1, title: "강남구 정책정보를 알려드립니다", author: "홍길동", date: "2023-11-30" },
        { id: 2, title: "강서구 정책정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 3, title: "서대문구 정책정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 4, title: "마포구 정책정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 5, title: "중구 정책정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 6, title: "종로구 정책정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
        { id: 7, title: "용산구 정책정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
    ];



    var tableBody = document.querySelector("#board-table tbody");
    for (var i = 0; i < posts.length; i++) {
        var row = document.createElement("tr");


        var idCell = document.createElement("td");
        idCell.textContent = posts[i].id;

        var titleCell = document.createElement("td");
        titleCell.innerHTML = '<a href ="#" style="color: #1c3664;">' + posts[i].title + "</a>";

        var authorCell = document.createElement("td");
        authorCell.textContent = posts[i].author;

        var dateCell = document.createElement("td");
        dateCell.textContent = posts[i].date;

        row.appendChild(idCell);
        row.appendChild(titleCell);
        row.appendChild(authorCell);
        row.appendChild(dateCell);

        tableBody.appendChild(row);


    }



    var chartData = {
        labels: ['서울특별시', '부산광역시', '대구광역시', '인천광역시', '광주광역시', '대전광역시', '울산광역시', '세종시', '경기도', '강원도', '충청북도', '충청남도', '전라북도', '전라남도', '경상북도', '경상남도', '제주도'],
        datasets: [{
            label: '60세 이상',
            data: [2437410, 1039667, 669973, 747038, 338295, 356489, 271967, 63389, 3159043, 513783, 472607, 632738, 577740, 638130, 874604, 960906, 173639],
            // backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
        }]
    };

    var ctx = document.getElementById("mainChart").getContext("2d");

    var myChart = new Chart(ctx, {
        type: "bar", // 차트 유형을 변경할 수 있습니다 (예: 'bar', 'line', 'pie' 등)
        data: chartData,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '2023년 각 지역 60세 이상 인구수 데이터',

                    padding: {
                        top: 10,
                        bottom: 30
                    }

                }
            }
            ,
            scales: {
                y: {
                    beginAtZero: false
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        },
    });
};

