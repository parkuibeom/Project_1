//서블릿에서 데이터를 JSON 형태로 받아옴
//서버는 아직 미구현이기에 임시로 JSON 형식 데이터 할당
//데이터는 지역 -> 연도 -> 4대 질병(고지혈증, 치매, 당뇨, 고혈압) 순으로 저장
var newChart;
var seoulRegion;
var jeonnamRegion;
var labelData = []; //라벨 데이터

var selectYearStart = document.getElementById("year-select-start");
var selectYearEed = document.getElementById("year-select-end");
var selectYearStartValue
var selectYearEndValue


var seoulSelect = document.getElementById('seoul-select');
var seoulSelectValue



//강남 고지혈증, 치매, 당뇨병, 고혈압 임시 변수
var gangnamInputHyper;
var gangnamInputDementia;
var gangnamInputDiabetes;
var gangnamInputHbp;



//고지혈증, 치매, 당뇨, 고혈압 순 데이터
var gangnamHyperlipidemia = [];
var gangnamDementia = [];
var gangnamDiabetes = [];
var gangnamHbp = [];


//각 질병 버튼 상태
var hyperBtnStatus = "off";
var demenBtnStatus = "off";
var diaBtnStatus = "off";
var hbpBtnStatus = "off";


var gangnamData = { //강남 데이터
    2013: {
        'hyperlipidemia': 40,   // 고지혈증
        'dementia': 15,        // 치매
        'diabetes': 30,        // 당뇨
        'hbp': 45              // 고혈압
    },
    2014: {
        'hyperlipidemia': 42,
        'dementia': 16,
        'diabetes': 32,
        'hbp': 47
    },
    2015: {
        'hyperlipidemia': 38,
        'dementia': 14,
        'diabetes': 28,
        'hbp': 43
    },
    2016: {
        'hyperlipidemia': 41,
        'dementia': 17,
        'diabetes': 31,
        'hbp': 46
    },
    2017: {
        'hyperlipidemia': 39,
        'dementia': 18,
        'diabetes': 29,
        'hbp': 44
    },
    2018: {
        'hyperlipidemia': 43,
        'dementia': 20,
        'diabetes': 34,
        'hbp': 50
    },
    2019: {
        'hyperlipidemia': 37,
        'dementia': 13,
        'diabetes': 27,
        'hbp': 42
    },
    2020: {
        'hyperlipidemia': 44,
        'dementia': 19,
        'diabetes': 35,
        'hbp': 51
    },
    2021: {
        'hyperlipidemia': 36,
        'dementia': 12,
        'diabetes': 26,
        'hbp': 41
    },
    2022: {
        'hyperlipidemia': 45,
        'dementia': 21,
        'diabetes': 36,
        'hbp': 52
    },
    2023: {
        'hyperlipidemia': 45,
        'dementia': 21,
        'diabetes': 36,
        'hbp': 52
    }
};


function initData() {
    labelData = []; //라벨 데이터 초기화
    //데이터 초기화
    gangnamHyperlipidemia = [];
    gangnamDementia = [];
    gangnamDiabetes = [];
    gangnamHbp = [];


    selectYearStartValue = selectYearStart.options[selectYearStart.selectedIndex].value;
    selectYearEndValue = selectYearEed.options[selectYearEed.selectedIndex].value;

    seoulSelectValue = seoulSelect.options[seoulSelect.selectedIndex].value;






    for (let i = selectYearStartValue; i <= selectYearEndValue; i++) {
        labelData.push(i);
        gangnamHyperlipidemia.push(gangnamData[i]["hyperlipidemia"]);
        gangnamDementia.push(gangnamData[i]["dementia"]);
        gangnamDiabetes.push(gangnamData[i]["diabetes"]);
        gangnamHbp.push(gangnamData[i]["hbp"]);

    }
    //하나의 연도만 출력
    // labelData.push(selectStart);
    // gangnamHyperlipidemia.push(gangnamData[selectStart]["hyperlipidemia"]);
    // gangnamDementia.push(gangnamData[selectStart]["dementia"]);
    // gangnamDiabetes.push(gangnamData[selectStart]["diabetes"]);
    // gangnamHbp.push(gangnamData[selectStart]["hbp"]);

    // haenamHyperlipidemia.push(haenamData[selectStart]["hyperlipidemia"]);
    // haenamDementia.push(haenamData[selectStart]["dementia"]);
    // haenamDiabetes.push(haenamData[selectStart]["diabetes"]);
    // haenamHbp.push(haenamData[selectStart]["hbp"]);

}

//질병 데이터 체크 함수
function checkBtn() {
    //고지혈증 버튼
    if (hyperBtnStatus === "on") {
        gangnamInputHyper = gangnamHyperlipidemia;

    }

    else if (hyperBtnStatus === "off") {
        gangnamInputHyper = [];

    }

    //치매 버튼
    if (demenBtnStatus === "on") {
        gangnamInputDementia = gangnamDementia;

    }

    else if (demenBtnStatus === "off") {
        gangnamInputDementia = [];

    }

    //당뇨병 버튼
    if (diaBtnStatus === "on") {
        gangnamInputDiabetes = gangnamDiabetes;

    }

    else if (diaBtnStatus === "off") {
        gangnamInputDiabetes = [];

    }

    //고혈압 버튼
    if (hbpBtnStatus === "on") {
        gangnamInputHbp = gangnamHbp;

    }

    else if (hbpBtnStatus === "off") {
        gangnamInputHbp = [];

    }
}

function regionCheck() {
    initData();
    checkBtn()
    //지역 체크 함수
    newChart.destroy();
    // for (let i = 0; i < labelData.length; i++) {
    //     if (typeof labelData[i] === 'string') {
    //         labelData[i] = parseInt(labelData[i]);
    //     }
    // }
    if (hyperBtnStatus === "on") {
        newChart.destroy;
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '서울시 고지혈증',
                    data: gangnamInputHyper,
                    borderWidth: 1,
                    backgroundColor: ['red'],
                    borderColor: ['red']
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고지혈증 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (demenBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '서울시 치매',
                    data: gangnamInputDementia,
                    borderWidth: 1,
                    backgroundColor: ['yellow'],
                    borderColor: ['yellow']
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '치매 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (diaBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '서울시 당뇨',
                    data: gangnamInputDiabetes,
                    borderWidth: 1,
                    backgroundColor: ['black'],
                    borderColor: ['black']
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '당뇨 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (hbpBtnStatus === "on") {

        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '서울시 고혈압',
                    data: gangnamInputHbp,
                    borderWidth: 1,
                    backgroundColor: ['lightblue'],
                    borderColor: ['lightblue']
                }
                ]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고혈압 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
}

//창 로딩시 
window.onload = function () {
    new WOW().init();
}






//차트 DOM으로 받아오기
var ctx = document.getElementById('myChart');

labelData = Object.keys(gangnamData);


//차트 데이터
let chartData = {
    type: 'bar',
    data: {
        labels: labelData, //x라벨
        datasets: [{ //chart에 넣을 데이터
            label: '고지혈증',
            borderWidth: 1,
            backgroundColor: ['red'],
            borderColor: ['red']
        },
        {
            label: '치매',
            borderWidth: 1,
            backgroundColor: ['yellow'],
            borderColor: ['yellow']
        },
        {
            label: '당뇨    ',
            borderWidth: 1,
            backgroundColor: ['black'],
            borderColor: ['black']
        },
        {
            label: '고혈압',
            borderWidth: 1,
            backgroundColor: ['lightblue'],
            borderColor: ['lightblue']
        }]
    },
    options: {
        plugins: {
            title: {
                display: true,
                text: '지역 데이터(단위 : %)',
                font: {
                    size: 20,
                },
                padding: {
                    top: 10,
                    bottom: 30
                }
            }
        }
        ,
        scales: {
            y: {
                beginAtZero: true
            }
        }
        , responsive: true, //차트 반응형 옵션
        maintainAspectRatio: true,
    }
}

//차트 틀 생성
newChart = new Chart(ctx, chartData);





//셀렉트 박스 차트 적용(xlabel 범위)
// document.getElementById('year-select-start').addEventListener('change', function () {
//     selectStart = document.getElementById('year-select-start').value;
//     if (region === undefined) {
//         selectEnd = document.getElementById('year-select-end').value;
//         alert("지역을 선택해주세요");
//     }
//     initData();

//     checkBtn();
//     regionCheck();

// });

// document.getElementById('year-select-end').addEventListener('change', function () {
//     selectStart = document.getElementById('year-select-start').value;
//     if (region === undefined) {
//         selectEnd = document.getElementById('year-select-end').value;
//         alert("지역을 선택해주세요");
//     }
//     initData();

//     checkBtn();
//     regionCheck();

// });



// 강남 셀렉트 차트 적용(데이터)
document.getElementById('seoul-select').addEventListener('change', function () {
    seoulSelect = document.getElementById('seoul-select');
    seoulSelectValue = seoulSelect.options[seoulSelect.selectedIndex].value;
    // if (seoulSelectValue !== "0") {
    //     seoulRegion = parseInt(seoulSelectValue);
    // }
    seoulSelectValue;
    newChart.destroy();
    checkBtn();
    regionCheck();

});



//고지혈증 버튼
document.getElementById('hyper').addEventListener('click', function () {
    if (hyperBtnStatus === "on") {
        hyperBtnStatus = "off"
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (hyperBtnStatus === "off") {
        hyperBtnStatus = "on";
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;

    }
    else {
        alert("지역을 선택해주세요");
    }
    checkBtn();
    regionCheck();

})

//치매 버튼
document.getElementById('dementia').addEventListener('click', function () {
    if (demenBtnStatus === "on") {
        demenBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (demenBtnStatus === "off") {
        demenBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }


    checkBtn();
    regionCheck();

})

//당뇨 버튼
document.getElementById('diabetes').addEventListener('click', function () {
    if (diaBtnStatus === "on") {
        diaBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (diaBtnStatus === "off") {
        diaBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    checkBtn();
    regionCheck();
})

//고혈압 버튼
document.getElementById('hbp').addEventListener('click', function () {
    if (hbpBtnStatus === "on") {
        hbpBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
    }
    else if (hbpBtnStatus === "off") {
        hbpBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }

    checkBtn();
    regionCheck();

})



function addYearOption() {
    removeYearOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2023; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}